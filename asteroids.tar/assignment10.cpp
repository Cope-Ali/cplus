/***********************************************************************
* Program:
*    Assignment 10, Hello World        
*    Brother Honeycutt, CS124
* Author:
*    Ali Cope
* Summary: 
*    This is the first C++ program that I have ever written. The purpose of
*    this project is to get me familiar with using LinuxLab and writing in
*    C++. This program should display "Hello World" on the screen.
*
*    Estimated:  0.75 hrs   
*    Actual:     0.0 hrs
*      I had a difficult time figuring out how to create the assignment in
*      Linux lab. I am so used to being able to click to search or accomplish
*      tasks. It has been quite a change to do it this way. Once I figured out
*      how to copy the template and start my assignment it wasn't too difficult
************************************************************************/

#include <iostream>
using namespace std;

/**********************************************************************
 * Display "Hello World" on the screen
 ***********************************************************************/
int main()
{
   cout << "Hello World\n";
   return 0;
}
