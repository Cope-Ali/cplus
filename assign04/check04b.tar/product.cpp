/***************************************************************
 * File: product.cpp
 * Author: Ali Cope
 * Purpose: Contains the method implementations for the Product class.
 ***************************************************************/

#include <iostream>
#include <string>
#include <iomanip>
#include "product.h"
using namespace std;

// put your method bodies here
void Product :: prompt()
{
   cout << "Enter Name: ";
   getline(cin, name);
   cin.ignore();
   cout << "Enter description: ";
   getline(cin, description);
   cout << "Enter weight: ";
   cin >> weight;
   cout << "Enter Price: ";
   cin >> basePrice;
}

float Product :: getSalesTax()
{
   float tax = basePrice * 6 / 100;
   return tax;
}

float Product :: getShippingCost()
{
   float cost;
   if (weight > 5)
      cost = 2;
   else
      cost = 2 + (weight / 10);
   return cost;
}

float Product :: getTotalPrice()
{
   float total = basePrice + getSalesTax() + getShippingCost(); 
   return total;
}

void Product :: displayAdvertising()
{
   cout.setf(ios::fixed);
   cout.setf(ios::showpoint);
   cout.precision(2); 

   cout << name << " - $" << basePrice << endl << "(" << description
        << ")" << endl; 
}

void Product :: displayInventory()
{
   cout.setf(ios::fixed);
   cout.setf(ios::showpoint);
   cout.precision(2); 

   cout << "$" << basePrice << " - " << name << " - " << weight << " lbs\n";
}

void Product :: displayReceipt()
{
   cout.setf(ios::fixed);
   cout.setf(ios::showpoint);
   cout.precision(2);
   
   cout << name
        << "\tPrice:" << setw(16) << "$" << setw(8) << basePrice << endl
        << "\tSales Tax:" << setw(16) << "$" << setw(8)
        << getSalesTax() << endl
        << "\tShipping Cost:" << setw(16) << "$" << setw(8)
        << getShippingCost() << endl
        << "\tTotal:" << setw(16) << "$" << setw(8) << getTotalPrice() << endl;
}
