/************************************************************
 * Source File:
 *    BIRD:
 * Author:
 *    Ali Cope
 * Description: Contains the implementations of the
 *  method bodies for the bird class.
 ************************************************************************/

#include "bird.h"
#include "uiDraw.h"

#include <iostream>

NormalBird::NormalBird(const Point & point) : Bird(point)
{
    float dx = random (3,6);
    float dy = random (1,4);

    if (point.getY() > 0)
    {
        dy *=-1;
    }
    Velocity newVelocity;
    newVelocity.setDx(dx);
    newVelocity.setDy(dy);

    setVelocity(newVelocity);

}

void NormalBird :: draw()
{
    if(alive)
    {
        drawCircle(point, BIRD_RADIUS);
    }
}

int NormalBird :: hit()
{
    kill();
    return POINTS_NORMAL_BIRD;
}

SacredBird::SacredBird(const Point & point) : Bird(point)
{
    float dx = random (3,6);
    float dy = random (1,4);

    if (point.getY() > 0)
    {
        dy *=-1;
    }
    Velocity newVelocity;
    newVelocity.setDx(dx);
    newVelocity.setDy(dy);

    setVelocity(newVelocity);

}

void SacredBird :: draw()
{
    if(alive)
    {
        drawCircle(point, BIRD_RADIUS);
    }
}

int SacredBird :: hit()
{
    kill();
    return POINTS_SACRED_BIRD;
}

ToughBird::ToughBird(const Point & point) : Bird(point)
{
    float dx = random (3,6);
    float dy = random (1,4);

    if (point.getY() > 0)
    {
        dy *=-1;
    }
    Velocity newVelocity;
    newVelocity.setDx(dx);
    newVelocity.setDy(dy);

    setVelocity(newVelocity);

}

void ToughBird :: draw()
{
    if(alive)
    {
        drawCircle(point, BIRD_RADIUS);
    }
}

int ToughBird :: hit()
{
    kill();
    return POINTS_TOUGH_BIRD_KILL;
}
