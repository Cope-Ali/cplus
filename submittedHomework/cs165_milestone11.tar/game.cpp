/*********************************************************************
 * File: game.cpp
 * Description: Contains the implementaiton of the game class
 *  methods.
 *
 *********************************************************************/

#include "game.h"

// These are needed for the getClosestDistance function...
#include <limits>
#include <algorithm>

#include <vector>
#include "uiDraw.h"
#include "uiInteract.h"
#include "ship.h"
#include "rocks.h"
#include "bullet.h"
#include "flyingObjects.h"

using namespace std;
#define OFF_SCREEN_BORDER_AMOUNT 5

Game::Game(Point tl, Point br) : topLeft(tl), bottomRight(br)
{
  Point newPoint;
  newPoint.setRandom();
  Ship ship();
  while (rocks.size() < 5)
  {
    rocks.push_back(new BigRock());
  }
}

/*********************************************
    * Function: advance
    * Description: Move everything forward one
    *  step in time.
    *********************************************/
void Game::advance()
{
  advanceBullets();
  advanceRocks();
  advanceShip();

  handleCollisions();
  cleanUpZombies();
}

/***************************************
 * GAME :: ADVANCE BULLETS
 * Go through each bullet and advance it.
 ***************************************/
void Game::advanceBullets()
{
  // Move each of the bullets forward if it is alive
  for (int i = 0; i < bullets.size(); i++)
  {
    if (bullets[i].isAlive())
    {
      // this bullet is alive, so tell it to move forward
      bullets[i].advance();

      if (!isOnScreen(bullets[i].getPoint()))
      {
        // the bullet has left the screen
        bullets[i].kill();
      }
    }
  }
}

void Game::advanceShip()
{
  //make sure ship is alive
  if (ship.isAlive())
  {
    //move ship
    ship.advance();
  }
}

void Game::advanceRocks()
{
  // Move each of the rocks forward if it is alive
  for (int i = 0; i < rocks.size(); i++)
  {
    rocks[i]->advance();
  }
}

/*********************************************
    * Function: handleInput
    * Description: Takes actions according to whatever
    *  keys the user has pressed.
    *********************************************/
void Game::handleInput(const Interface &ui)

{
  if (ui.isUp())
  {
    ship.applyThrust();
  }

  if (ui.isLeft())
  {
    ship.rotateLeft();
  }

  if (ui.isRight())
  {
    ship.rotateRight();
  }

  // Check for "Spacebar
  if (ui.isSpace())
  {
    Bullet newBullet;
    newBullet.fire(ship.getPoint(), ship.getAngle(), ship.getVelocity());

    bullets.push_back(newBullet);
  }
}

/*********************************************
    * Function: draw
    * Description: draws everything for the game.
    *********************************************/
void Game::draw(const Interface &ui)
{

  //Rocks vector draw loop
  for (int i = 0; i < rocks.size(); i++)
  {
    //if (rocks[i]->isAlive())
    //{
    rocks[i]->draw();
    //}
  }

  // draw ship
  ship.draw();

  // draw bullets if they are alive
  for (int i = 0; i < bullets.size(); i++)
  {
    if (bullets[i].isAlive())
    {
      bullets[i].draw();
    }
  }
}

/*****************************************************************
 * GAME :: IS ON SCREEN
 * Determines if a given point is on the screen.
 ****************************************************************/
bool Game::isOnScreen(const Point &point)
{
  return (point.getX() >= topLeft.getX() - OFF_SCREEN_BORDER_AMOUNT && point.getX() <= bottomRight.getX() + OFF_SCREEN_BORDER_AMOUNT && point.getY() >= bottomRight.getY() - OFF_SCREEN_BORDER_AMOUNT && point.getY() <= topLeft.getY() + OFF_SCREEN_BORDER_AMOUNT);
}

/*****************************************************************
 * GAME :: HANDLE COLLISIONS
 * Check for a collision between a rock and a bullet, 
 * or ship and rock?
 *****************************************************************/
void Game::handleCollisions()
{
  // now check for a hit (if it is close enough to any live bullets)
  for (int i = 0; i < bullets.size(); i++)
  {
    if (bullets[i].isAlive())
    {
      // this bullet is alive, see if its too close
      for (int r = 0; r < rocks.size(); r++)
      {
        if (getClosestDistance(*rocks[r], bullets[i]) <= rocks[r]->getRadius())
        {
          bullets[i].kill();
          cleanUpZombies();
          std::cout << "crash";

          /* causes seg fault 
          if (rocks[r]->getRadius() > 8)
          { 
            //create first medium rock
            MediumRock mRock1;
            //set to point of large rock
            mRock1.setPoint(rocks[r]->getPoint());
            //set velocity to one up
            Velocity m1Velocity;
            m1Velocity.setDx(rocks[r]->getVelocity().getDx());
            m1Velocity.setDy(rocks[r]->getVelocity().getDy() + 1);
            mRock1.setVelocity(m1Velocity);

            //create second rock
            MediumRock mRock2;
            //set to point of large rock
            mRock2.setPoint(rocks[r]->getPoint());
            //set velocity to one down
            Velocity m2Velocity;
            m2Velocity.setDx(rocks[r]->getVelocity().getDx());
            m2Velocity.setDy(rocks[r]->getVelocity().getDy() - 1);
            mRock2.setVelocity(m2Velocity);

            //create small rock
            SmallRock sRock1;
            //set small rock to point of large rock
            sRock1.setPoint(rocks[r]->getPoint());
            //set velocity to two to the right
            Velocity s1Velocity;
            s1Velocity.setDx(rocks[r]->getVelocity().getDx() + 2);
            s1Velocity.setDy(rocks[r]->getVelocity().getDy());
            sRock1.setVelocity(s1Velocity);

            //draw all the rocks
            mRock1.draw();
            mRock2.draw();
            sRock1.draw();

            //push rocks into vector
            rocks.push_back(&mRock1);
            rocks.push_back(&mRock2);
            rocks.push_back(&sRock1);
          }
 
          else if (rocks[r]->getRadius() > 4)
          {
          }

          else
          {
          }
*/
          rocks[r]->hit();
        }
      }
    }
  }
}

/* {
// loop through each asteroid check to see if it was hit
      for (int r = 0; r < rocks.size(); r++)
        {
          Rock rock = rocks[r];
          if (getClosestDistance(bullets[i],rock) <= rocks[r]->getRadius())
        {
        bullets[r].kill();
        rocks[i]->kill();
        }
        }
} */

/**************************************************************
 * GAME :: CLEAN UP ZOMBIES
 * Remove any dead objects (take bullets out of the list, take rocks out of the list)
 ****************************************************************/
void Game::cleanUpZombies()
{
  /* clean up bullets that are dead or have exsisted
  for more than 40 frames*/
  for (int i = 0; i < bullets.size(); i++)
  {
    if (!bullets[i].isAlive() || bullets[i].getCount() >= 40)
      bullets[i].kill();
  };

  // clean up dead asteroids

  //clean up dead ship
}

// You may find this function helpful...

/**********************************************************
 * Function: getClosestDistance
 * Description: Determine how close these two objects will
 *   get in between the frames.
 **********************************************************/

float Game::getClosestDistance(const FlyingObjects &obj1, const FlyingObjects &obj2) const
{
  // find the maximum distance traveled
  float dMax = max(abs(obj1.getVelocity().getDx()), abs(obj1.getVelocity().getDy()));
  dMax = max(dMax, abs(obj2.getVelocity().getDx()));
  dMax = max(dMax, abs(obj2.getVelocity().getDy()));
  dMax = max(dMax, 0.1f); // when dx and dy are 0.0. Go through the loop once.

  float distMin = std::numeric_limits<float>::max();
  for (float i = 0.0; i <= dMax; i++)
  {
    Point point1(obj1.getPoint().getX() + (obj1.getVelocity().getDx() * i / dMax),
                 obj1.getPoint().getY() + (obj1.getVelocity().getDy() * i / dMax));
    Point point2(obj2.getPoint().getX() + (obj2.getVelocity().getDx() * i / dMax),
                 obj2.getPoint().getY() + (obj2.getVelocity().getDy() * i / dMax));

    float xDiff = point1.getX() - point2.getX();
    float yDiff = point1.getY() - point2.getY();

    float distSquared = (xDiff * xDiff) + (yDiff * yDiff);

    distMin = min(distMin, distSquared);
  }

  return sqrt(distMin);
}
