#include "rocks.h"
#include "uiDraw.h"

// Put your Rock methods here

//BIG_ROCK
BigRock::BigRock()
{
    alive = true;
    //start at a random point
    point.setRandom();
    // get a random dx and dy for velocity
    float dx = cos(random(-1, 1) * (M_PI / 2));
    float dy = cos(random(-1, 1) * (M_PI / 2));
    // randomly change direction
    int num1 = random(1, 4);
    if (num1 = 2)
        dx *= -1;
    int num2 = random(1, 4);
    if (num2 = 2)
        dy *= -1;
    //set random velocity
    Velocity newVelocity;
    newVelocity.setDx(dx);
    newVelocity.setDy(dy);
    setVelocity(newVelocity);
    setRadius(BIG_ROCK_SIZE);
}

void BigRock::draw()
{
    if(alive)
    {
    if (point.getY() < -200)
        point.setY(200);

    if (point.getY() > 200)
        point.setY(-200);

    if (point.getX() < -200)
        point.setX(200);

    if (point.getX() > 200)
        point.setX(-200);

    setSpin(getSpin() + BIG_ROCK_SPIN);
    drawLargeAsteroid(point, spin);
    }
}

int BigRock::hit()
{
   /* causes rocks to appear once then disappear, falling out?
   //create first medium rock
   MediumRock mRock1;
   //set to point of large rock
   mRock1.setPoint(point);
   //set velocity to one up
   Velocity m1Velocity;
   m1Velocity.setDx(velocity.getDx());
   m1Velocity.setDy(velocity.getDy()+1);
   mRock1.setVelocity(m1Velocity);

   //create second rock
   MediumRock mRock2;
   //set to point of large rock
   mRock2.setPoint(point);
   //set velocity to one down
   Velocity m2Velocity;
   m2Velocity.setDx(velocity.getDx());
   m2Velocity.setDy(velocity.getDy()-1);
   mRock2.setVelocity(m2Velocity);

   //create small rock
   SmallRock sRock1;
   //set small rock to point of large rock
   sRock1.setPoint(point);
   //set velocity to two to the right
   Velocity s1Velocity;
   s1Velocity.setDx(velocity.getDx()+2);
   s1Velocity.setDy(velocity.getDy());
   sRock1.setVelocity(s1Velocity);

   //draw all the rocks
mRock1.draw();
mRock2.draw();
sRock1.draw();

//push rocks into vector
rocks.push_back(&mRock1);
rocks.push_back(&mRock2);
rocks.push_back(&sRock1); */

   kill();
    return 0;
}

MediumRock::MediumRock()
{
    alive = true;
    setRadius(MEDIUM_ROCK_SIZE);
}

void MediumRock::draw()
{
    if (alive)
    {
        if (point.getY() < -200)
            point.setY(200);

        if (point.getY() > 200)
            point.setY(-200);

        if (point.getX() < -200)
            point.setX(200);

        if (point.getX() > 200)
            point.setX(-200);

        setSpin(getSpin() + MEDIUM_ROCK_SPIN);

        drawMediumAsteroid(point, spin);
    }
}

int MediumRock::hit()
{
      //create small rock
   SmallRock sRock1;
   //set small rock to point of medium rock
   sRock1.setPoint(point);
   //set velocity to three to the right
   Velocity s1Velocity;
   s1Velocity.setDx(velocity.getDx()+3);
   s1Velocity.setDy(velocity.getDy());
   sRock1.setVelocity(s1Velocity);

    //create small rock
   SmallRock sRock2;
   //set small rock to point of medium rock
   sRock2.setPoint(point);
   //set velocity to three to the left
   Velocity s2Velocity;
   s2Velocity.setDx(velocity.getDx()-3);
   s2Velocity.setDy(velocity.getDy());
   sRock2.setVelocity(s2Velocity);

//draw all the rocks
sRock1.draw();
sRock2.draw();


//push rocks into vector
rocks.push_back(&sRock1);
rocks.push_back(&sRock2);


    kill();
    return 0;
}

//SMALL ROCK
SmallRock::SmallRock()
{
    alive=true;
    setRadius(SMALL_ROCK_SIZE);
}

void SmallRock::draw()
{
    if (alive)
    {
        setSpin(getSpin() + SMALL_ROCK_SPIN);
        drawSmallAsteroid(point, spin);
    }
}

int SmallRock::hit()
{
    kill();
    return 0;
}