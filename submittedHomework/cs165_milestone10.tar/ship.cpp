#include "ship.h"

// Put your ship methods here


void Ship::draw()
{
    if (alive)
    {
        drawShip(point, angle, true);
    }
}

int Ship::hit()
{
    kill();
    return 0;
}

void Ship::rotateLeft()
{
    setAngle(getAngle()-ROTATE_AMOUNT);
}
void Ship::rotateRight()
{
    setAngle(getAngle()+ROTATE_AMOUNT);
}

void Ship::applyThrust()
{    

  velocity.setDx(velocity.getDx()+ THRUST_AMOUNT * (-cos(M_PI / 180 * angle)));
  velocity.setDy(velocity.getDy()+ THRUST_AMOUNT * (sin(M_PI / 180 * angle)));
}