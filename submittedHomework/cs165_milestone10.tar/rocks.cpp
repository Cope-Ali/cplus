#include "rocks.h"
#include "uiDraw.h"

// Put your Rock methods here


//BIG_ROCK
BigRock::BigRock()
{
    //start at a random point
    point.setRandom();
// get a random dx and dy for velocity
    float dx = cos(random(-1,1)*(M_PI/2));
    float dy = cos(random(-1,1)*(M_PI/2));
// randomly change direction
    int num1 = random(1,4);
    if (num1 = 2)
    dx*=-1;
    int num2 = random(1,4);
    if(num2 = 2)
    dy*=-1;
//set random velocity
    Velocity newVelocity;
    newVelocity.setDx(dx);
    newVelocity.setDy(dy);
    setVelocity(newVelocity);
}

void BigRock::draw()
{ 
    setSpin(getSpin() + BIG_ROCK_SPIN);
        drawLargeAsteroid(point, spin);
}

int BigRock::hit()
{
    kill();
    return 0;
}

//MEDIUM_ROCK
MediumRock::MediumRock(const Point &point) : Rock(point)
{
    float dx = random(3, 6);
    float dy = random(1, 4);

    if (point.getY() > 0)
    {
        dy *= -1;
    }
    Velocity newVelocity;
    newVelocity.setDx(dx);
    newVelocity.setDy(dy);

    setVelocity(newVelocity);

}

void MediumRock::draw()
{
    if(alive)
    {
        drawMediumAsteroid(point, MEDIUM_ROCK_SPIN);
    }
}

int MediumRock::hit()
{
    kill();
    return 0;
}

//SMALL ROCK
SmallRock::SmallRock(const Point &point) : Rock(point)
{
    float dx = random(3, 6);
    float dy = random(1, 4);

    if (point.getY() > 0)
    {
        dy *= -1;
    }
    Velocity newVelocity;
    newVelocity.setDx(dx);
    newVelocity.setDy(dy);

    setVelocity(newVelocity);

}

void SmallRock::draw()
{
    if(alive)
    {
        drawSmallAsteroid(point, SMALL_ROCK_SPIN);
    }
}

int SmallRock::hit()
{
    kill();
    return 0;
}