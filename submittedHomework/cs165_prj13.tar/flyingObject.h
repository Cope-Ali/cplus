#ifndef flyingObject_h
#define flyingObject_h




// Put your FlyingObject class here




#endif /* flyingObject_h */
